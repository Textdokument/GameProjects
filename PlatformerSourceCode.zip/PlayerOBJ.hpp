#pragma once
#include<SFML/Graphics.hpp>

class Player {
public:
	Player() {

		PlayerRect.setSize(sf::Vector2f(35, 70));
		PlayerRect.setFillColor(sf::Color(204, 4, 204));
		PlayerRect.setPosition(PlayerPos);
	}
	~Player() {}

	int PlayerBottom() {
		return PlayerRect.getGlobalBounds().top + PlayerRect.getGlobalBounds().height;
	}


	//Hier wird die Globale Position des Spielers erkannt, spricht die Position aller 4 ecken, dies wird genutzt um die kollision mit anderen objekten zu testen
	sf::FloatRect GetGlobal() {
		return PlayerRect.getGlobalBounds();
	}

	//die Funktion wird genutzt wenn der Spieler Kollidiern tut damit er wieder springen kann
	void Colliding() {
		Velocity = 0;
		hasJumped = false;
	}
	//die Funktion wird genutzt wenn der Spieler Kollidiern tut damit er wieder springen kann
	void CollidingVariables(bool collidingTest = false) {
		isColliding = collidingTest;
	}

	//Hier wird erkannt welche taste gedr�ckt wird, je nachdem wird eine variable auf true/false gesetzt damit der spieler sich dann so bewegt
	void Movement() {
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space) && !hasJumped) {
			Jumping = true;
			hasJumped = true;
		}
		else { Jumping = false; }

		if (sf::Keyboard::isKeyPressed(sf::Keyboard::A) || sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) {
			Left = true;
		}
		else { Left = false; }
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::D) || sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) {
			Right = true;
		}
		else { Right = false; }

	}

	//Hiermit soll man die x,y position des Spielers bekommen
	sf::Vector2f GetPosition() {
		return PlayerPos;
	}

	void SetPosition_Y(int Y) {
		PlayerPos.y = Y;
		PlayerRect.setPosition(PlayerPos);
	}

	//Hier soll die X und Y Position des Spielers Festgeleckt werden
	void SetPosition(sf::Vector2f XY) {
		PlayerPos = XY;
		PlayerRect.setPosition(PlayerPos);
	}


	//Hier wird alles mit der Bewegung gemacht, wenn die Variablen auf true sind bewegt/springt der Spieler
	void update(sf::Time dt) {
		if (Jumping) {

			Velocity -= JumpHeight;
			PlayerPos.y += Velocity * dt.asSeconds();
		}
		if (!isColliding) {
			hasJumped = true;
			Velocity += 24;
			PlayerPos.y += Velocity * dt.asSeconds();
		}
		if (Left) {
			PlayerPos.x -= PlayerSpeed * dt.asSeconds();
		}
		else if (Right) {
			PlayerPos.x += PlayerSpeed * dt.asSeconds();
		}
		PlayerRect.setPosition(PlayerPos);
	}

	//Hier wird der Spieler auf das Fenster gezeichnet
	void draw(sf::RenderWindow& window) {
		window.draw(PlayerRect);
	}

private:
	//PlayerVisual
	sf::RectangleShape PlayerRect;
	sf::Vector2f PlayerPos;

	//PlayerMovement
	bool Left = false;
	bool Right = false;
	bool Jumping = false;
	bool hasJumped = false;


	//Gravity Physiks
	int JumpHeight = 666;
	int PlayerSpeed = 404;
	int Velocity = 0;
	bool isColliding = false;
};
