#include< SFML/Graphics.hpp >
#include< SFML/System.hpp   >
#include< SFML/Window.hpp   >
#include< SFML/Audio.hpp    >
#include< SFML/Network.hpp  >

#include<iostream>
#include"PlayerOBJ.hpp"
#include"CreateMap.hpp"

int MapArray[72] = {
    0,0,0,0,0,0,0,0,9,
    0,1,0,0,1,0,0,1,9,
    0,0,0,0,0,0,0,0,9,
    0,0,0,0,0,0,0,1,9,
    0,0,0,0,0,0,0,0,9,
    2,0,0,0,0,0,0,1,9,
    0,0,0,0,0,0,0,0,9,
    1,1,0,0,0,1,1,1,9,
};

int main() {
    //-------------------------------------x----y-----------------
    sf::RenderWindow window(sf::VideoMode(1080, 720), "SFML works!", sf::Style::Close);
    window.setFramerateLimit(60);
    sf::Clock clock;
    sf::Time time;
    sf::View view;
    view.setSize(1080, 720);

    Player myPlayer;

    sf::Vector2f Pos;

    Pos=CreateMap(MapArray);
    myPlayer.SetPosition(Pos);
    while (window.isOpen()) {
        sf::Event event;
        time = clock.restart();
        while (window.pollEvent(event)) {

            switch (event.type) {
            case sf::Event::Closed:
                window.close();
                break;

            }
        }

        if (myPlayer.GetPosition().y > 1600) {
            myPlayer.SetPosition(Pos);
        }

        view.setCenter(myPlayer.GetPosition());
        window.setView(view);
        myPlayer.Movement();
        myPlayer.update(time);
        

        window.clear(sf::Color(0, 1, 0));
        myPlayer.draw(window);

        for (Platform obj : GameMap) {
            obj.draw(window);
            if (myPlayer.GetGlobal().intersects(obj.GetGlobal())) {
                myPlayer.Colliding();
                myPlayer.CollidingVariables(true);
                if (myPlayer.PlayerBottom() > obj.PlatformTop()) {
                    myPlayer.SetPosition_Y(obj.PlatformTop() - 69);
                }
            }else{
                myPlayer.CollidingVariables(false);
            }
        }



        window.display();
    }

    return 0;
}
