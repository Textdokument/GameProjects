Hello, this is some source code of a platformer,
this code is smaller that the original, but whoever 
you are you can probably extend it