#include<iostream>
#include"PlatformerOBJ.hpp";

using namespace std;

vector<Platform> GameMap;

sf::Vector2f CreateMap(int array[]) {
	sf::Vector2f Pos;
	int x = 0, y = 0;
	for (int i = 0; i < 72; i++) {

		if (array[i] == 0) {
			printf(".");
			x += 120;
		}
		else if (array[i] == 1) {
			GameMap.emplace_back(x, y);
			printf("X");
			x += 120;
			
		}
		else if (array[i] == 2) {
			printf("P");
			x += 120;
			Pos.x = x;
			Pos.y = y;

		}
		else if (array[i] == 9) {
			printf("\n");
			x = 0;
			y += 120;
		}
		else {
			printf("?");
			x = +120;
		}
	}
	return Pos;
}