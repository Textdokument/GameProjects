#pragma once
#include<SFML/Graphics.hpp>

class Platform {
public:
	Platform(int x, int y) {
		PlatformPos.x = x;
		PlatformPos.y = y;
		PlatformRect.setFillColor(sf::Color(0, 0, 200));
		PlatformRect.setSize(sf::Vector2f(120, 21 + 1));
		PlatformRect.setPosition(PlatformPos);
	}
	~Platform() {}

	//Die Position der Oberen seite
	int PlatformTop() {
		return PlatformRect.getGlobalBounds().top;
	}

	//Hier wird die Globale Position der Platform erkannt, sprich die Position aller 4 ecken, dies wird genutzt um die kollision mit anderen objekten zu testen
	sf::FloatRect GetGlobal() {
		return PlatformRect.getGlobalBounds();
	}

	//Hier wird Die platform auf dem Fenster gezeigt
	void draw(sf::RenderWindow& window) {
		window.draw(PlatformRect);
	}

private:
	sf::RectangleShape PlatformRect;
	sf::Vector2f PlatformPos;
};